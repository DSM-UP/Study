from django.contrib import admin
from lists.models import List

admin.site.register(List)

# Register your models here.
