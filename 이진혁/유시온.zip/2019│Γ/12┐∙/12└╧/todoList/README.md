리스트 등록  /lists/add  addList()  addList.html

리스트(전체) 보기  /lists/all  showAll()  showAll.html

리스트 수정  /lists/\<str:l_name\>/mod  showOne()  modifyList.html

리스트 삭제  /lists/\<str:l_name\>/del  delList()  delList.html