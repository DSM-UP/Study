a = []

a.append(['a', 1, 2])
a.append(['b', 2, 3])

for i in a:
    print(i[0])