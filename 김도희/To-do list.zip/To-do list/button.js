function button() {
    localStorage.clear();
    location.reload();
}