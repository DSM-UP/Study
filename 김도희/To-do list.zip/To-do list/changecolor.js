/*

const title = document.querySelector("#title");

const clicks = "clicked";

function handle(){
    const has = title.classList.contains(clicks);

    title.classList.toggle(clicks);
    if(! has)
    {
        title.classList.add(clicks); 
    }
    else{
        title.classList.remove(clicks);
    }
}

function init()
{
    title.addEventListener("click", handle);
}

init();


*/