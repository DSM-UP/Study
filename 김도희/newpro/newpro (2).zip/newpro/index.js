const Exp = document.getElementById('exp');
const Pet = document.getElementById('pet');
const growth = document.getElementById('growth');
const click = document.getElementById('click');
const Music = document.getElementById('music');
const oneheart = document.getElementById('1');
const twoheart = document.getElementById('2');
const threeheart = document.getElementById('3');

const background = new Audio();
background.src = "C:\\Users\\user\\Desktop\\배경음.mp3";

const petsound = new Audio();
petsound.src = "C:\\Users\\user\\Desktop\\펫.mp3";

let  MusicOn = false;
let ExpNumber = 0;
let NowExp = null;
let heart = 1;

var nowheart = localStorage.getItem('nowheart');

if(nowheart > 0)
{
    heart = nowheart;
}

var saver = localStorage.getItem('ExpNumber');
var savervalue = parseInt(saver);

if(savervalue > 0)
{
    ExpNumber = savervalue;
    Exp.innerText = ExpNumber;
}
else{
    Exp.innerText = 0;
}

function onechange()
{
    if(heart > 0){
    oneheart.style.backgroundColor = "red";
    }
    if(heart > 1)
    {
        twoheart.style.backgroundColor = "red";
    }

    if(heart>2)
    {
        threeheart.style.backgroundColor = "red";
        }
    var nowheart = localStorage.setItem("nowheart", heart);
}

function start(){
    basic();

    ExpNumber += 1;
    console.log(ExpNumber);
    Exp.innerText = ExpNumber;

    localStorage.setItem("ExpNumber", ExpNumber);

    if(ExpNumber%10 === 0) 
    {
        Pet.src = "C:\\Users\\user\\Desktop\\newpro\\여(1)성장완료.gif";
        one();
        pet();
    }
}

function basic()
{
   Pet.src="C:\Users\\user\\Desktop\\newpro\\여(1)움짤.gif";
   growth.innerText = null;
   click.innerText = "펫을 클릭해 주세요!";
}


function one(){
    click.innerText = null;
   console.log("1차 성장"); 
    growth.innerHTML = "펫 성장 완료!";

    onechange();
    heart++;
}


function music() {
    if(MusicOn === false){
        MusicOn = true;
        Music.innerText = "Music Off";
        background.play();
        background.volume = 0.5;
        background.loop = true;
    }

    else{
        Music.innerText = "Music On";
        MusicOn = false;
        background.pause();
    };    
}
 
function pet(){
    petsound.play();
}

function resetpet()
{
    localStorage.clear();
    location.reload();
}

onechange();
Music.addEventListener("click", music);
Pet.addEventListener("click", start);
