const Exp = document.getElementById('exp');
const Pet = document.getElementById('pet');
const growth = document.getElementById('growth');
const click = document.getElementById('click');
const Music = document.getElementById('music');
const oneheart = document.getElementById('1');
const twoheart = document.getElementById('2');
const threeheart = document.getElementById('3');
let nowpet = 0;

const background = new Audio();
background.src = "C:\\Users\\user\\Desktop\\배경음.mp3";

const petsound = new Audio();
petsound.src = "C:\\Users\\user\\Desktop\\펫.mp3";

let  MusicOn = false;
let ExpNumber = 0;
let NowExp = null;
let heart = 1;

var nowheart = localStorage.getItem('nowheart');

if(nowheart !== null)
{
    heart = nowheart;
}

var saver = localStorage.getItem('ExpNumber');
var savervalue = parseInt(saver);

if(savervalue > 0)
{
    ExpNumber = savervalue;
    Exp.innerText = ExpNumber;
}
else{
    Exp.innerText = 0;
}

function onechange()
{
    if(heart > 1){
    oneheart.style.backgroundColor = "red";
    }
    if(heart > 2)
    {
        twoheart.style.backgroundColor = "red";
    }

    if(heart>3)
    {
        threeheart.style.backgroundColor = "red";
        localStorage.setItem("nowheart", heart)
        nowpet++;
        localStorage.setItem("nowpet", nowpet);
    }
}

function start(){
    basic();

    ExpNumber += 1;
    console.log(ExpNumber);
    Exp.innerText = ExpNumber;

    localStorage.setItem("ExpNumber", ExpNumber);

    if(ExpNumber%10 === 0 && ExpNumber < 30) 
    {
        Pet.src = "C:\\Users\\user\\Desktop\\newpro\\태어난여우 움짤.gif";
        one();
        pet();
    }

    else if(ExpNumber%10 === 0 && ExpNumber < 60) {
        Pet.src = "C:\\Users\\user\\Desktop\\newpro\\여(1)성장완료.gif";
        one();
        pet();
    }
}

function basic()
{
    if(nowpet !== 0){
        console.log("df");
        Pet.src="C:\\Users\\user\\Desktop\\newpro\\여(1)움짤.gif";
    }

    else if(nowpet === 0){
   Pet.src="C:\\Users\\user\\Desktop\\newpro\\여우(태어남).png";
    }
   growth.innerText = null;
   click.innerText = "펫을 클릭해 주세요!";
}


function one(){
    click.innerText = null;
   console.log("1차 성장"); 
    growth.innerHTML = "펫 성장 완료!";

    heart++;
    onechange();
}


function music() {
    if(MusicOn === false){
        MusicOn = true;
        Music.innerText = "Music Off";
        background.play();
        background.volume = 0.5;
        background.loop = true;
    }

    else{
        Music.innerText = "Music On";
        MusicOn = false;
        background.pause();
    };    
}
 
function pet(){
    petsound.play();
}

function resetpet()
{
    localStorage.clear();
    location.reload();
}

onechange();
Music.addEventListener("click", music);
Pet.addEventListener("click", start);
