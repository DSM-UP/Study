package com.example.miniproject;

public class Data {
    private String Recycler_btn1;
    private String Recycler_btn2;
    private String Recycler_btn3;
    private String Recycler_btn4;

    public String getRecycler_btn1() {
        return Recycler_btn1;
    }

    public void setRecycler_btn1(String recycler_btn1) {
        Recycler_btn1 = recycler_btn1;
    }

    public String getRecycler_btn2() {
        return Recycler_btn2;
    }

    public void setRecycler_btn2(String recycler_btn2) {
        Recycler_btn2 = recycler_btn2;
    }

    public String getRecycler_btn3() {
        return Recycler_btn3;
    }

    public void setRecycler_btn3(String recycler_btn3) {
        Recycler_btn3 = recycler_btn3;
    }

    public String getRecycler_btn4() {
        return Recycler_btn4;
    }

    public void setRecycler_btn4(String recycler_btn4) {
        Recycler_btn4 = recycler_btn4;
    }

    public String getRecycler_btn5() {
        return Recycler_btn5;
    }

    public void setRecycler_btn5(String recycler_btn5) {
        Recycler_btn5 = recycler_btn5;
    }

    public String getRecycler_btn6() {
        return Recycler_btn6;
    }

    public void setRecycler_btn6(String recycler_btn6) {
        Recycler_btn6 = recycler_btn6;
    }

    public String getRecycler_btn7() {
        return Recycler_btn7;
    }

    public void setRecycler_btn7(String recycler_btn7) {
        Recycler_btn7 = recycler_btn7;
    }

    public String getRecycler_btn8() {
        return Recycler_btn8;
    }

    public void setRecycler_btn8(String recycler_btn8) {
        Recycler_btn8 = recycler_btn8;
    }

    public String getRecycler_btn9() {
        return Recycler_btn9;
    }

    public void setRecycler_btn9(String recycler_btn9) {
        Recycler_btn9 = recycler_btn9;
    }

    private String Recycler_btn5;
    private String Recycler_btn6;
    private String Recycler_btn7;
    private String Recycler_btn8;
    private String Recycler_btn9;

}
